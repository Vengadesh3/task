const Footer = () => {
    return (
        <>
            <div className="footerSec">
                <h2>Footer Section</h2>
            </div>
        </>
    )
}

export default Footer;