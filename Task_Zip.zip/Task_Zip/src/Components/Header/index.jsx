const Header = ()=>{

    return(
        <>
            <div className="headerSec">
                <h2>Header Section</h2>
            </div>
        </>
    )
}

export default Header;