import { useEffect, useState, lazy } from "react";
import axios from "axios";
import { Heart } from 'lucide-react'
import { useNavigate } from "react-router-dom";

const Loader = lazy(() => import("../../Components/Loader"));

const ProductLists = () => {

    const [loading, setLoading] = useState(false);

    const [tempLists, setTempLists] = useState(false);
    const [search, setSearch] = useState('');
    const [productLists, setProductLists] = useState([]);



    const navigate = useNavigate();


    useEffect(() => {
        fetchProperties();
    }, []);

    const fetchProperties = async () => {
        try {
            setLoading(true);
            let response = await axios.get('https://mira-strapi-dev.q.starberry.com/api/properties/?_limit=50');
            if (response?.status === 200) {
                setTempLists(response?.data?.data);
                setProductLists(response?.data?.data);
                setLoading(false);
            }
        }
        catch (err) {
            setLoading(false);
        }
    }

    const redirect = (id) => {
        navigate(`/product-detail/${id}`)
    }

    const bedRoomsCount = [
        {
            name: 'All Bedrooms',
            value: 'all',
        },
        {
            name: '1 Bedroom',
            value: '1',
        },
        {
            name: '2 Bedrooms',
            value: '2',
        },
        {
            name: '3 Bedrooms',
            value: '3',
        },
        {
            name: '3+ Bedrooms',
            value: '4',
        }
    ]

    const sortPriceCategory = [
        {
            name: 'High to Low',
            value: 'high',
        },
        {
            name: 'Low to High',
            value: 'low',
        }

    ]

    const sortByBedRoom = (event) => {
        let type = event.target.value;
        if (type !== 'all' && type !== '4')
            // eslint-disable-next-line eqeqeq
            setTempLists(productLists?.filter((temp) => temp?.attributes?.bedroom == type));

        // eslint-disable-next-line eqeqeq
        else if (type == '4')
            setTempLists(productLists?.filter((temp) => temp?.attributes?.bedroom >= type));

        else
            setTempLists(productLists);
    }

    const sortByPrice = (event) => {
        let type = event.target.value;
        const sortedLists = [...productLists];
        if (type === 'high') {
            sortedLists?.sort((a, b) => +b.attributes.price - +a.attributes.price);

        }
        else {
            sortedLists?.sort((a, b) => a.attributes.price - b.attributes.price);
        }
        setTempLists(sortedLists)
    }

    useEffect(() => {
        if (search.length > 2) {
            const serachResults = productLists.filter((product) => {
                const title = product.attributes.title.toLowerCase();
                return title.includes(search.toLowerCase())
            });
            setTempLists(serachResults);
        }
        else
            setTempLists(productLists);
    }, [productLists, search]);

    return (
        <>
            <Loader loading={loading} />
            <div className="container-fluid p-0">
                <div className="mb-4">
                    <h3 className="text-center mb-4 p-5">Property for Sales</h3>
                    <div className="container mb-4 border-2">
                        <div className="d-flex justify-content-end mb-2">
                            <input
                                type="text"
                                className='searchInput'
                                placeholder="Search"
                                defaultValue={search}
                                onChange={(e) => setSearch(e.target.value)}
                            />
                        </div>
                        <div className="row align-items-center border-top border-bottom border-gray-500 border-0">
                            <div className="col-6 col-md">
                                <select className="form-select border-0" onClick={sortByBedRoom}>
                                    {
                                        bedRoomsCount.map((temp, index) =>
                                            <option key={index} value={temp?.value}>{temp?.name}</option>
                                        )
                                    }
                                </select>
                            </div>

                            <div className="col-6 col-md">
                                <select className="form-select border-0">
                                    <option>Any Neighbourhood</option>
                                </select>
                            </div>
                            <div className="col-6 col-md">
                                <select className="form-select border-0">
                                    <option>Min Price</option>
                                </select>
                            </div>
                            <div className="col-6 col-md">
                                <select className="form-select border-0">
                                    <option>Max Price</option>
                                </select>
                            </div>
                            <div className="col-6 col-md">
                                <select className="form-select border-0" onClick={(e) => sortByPrice(e)}>
                                    <option>Sort by</option>
                                    {
                                        sortPriceCategory.map((temp, index) =>
                                            <option key={index} value={temp?.value}>{temp?.name}</option>
                                        )
                                    }
                                </select>
                            </div>
                            <div className="col-6 col-md-auto">
                                <span className="d-block py-2">{tempLists?.length > 0 ? `${tempLists?.length} Results` : 'No Results'}</span>
                            </div>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row g-4">
                            {!loading && tempLists?.length > 0 ?
                                tempLists.map((temp, index) => (
                                    <div key={index} className="col-12 col-md-6 col-lg-4" style={{ cursor: 'pointer' }} onClick={() => redirect(temp?.id)}>
                                        <div className="card h-100 border-0">
                                            <div className="position-relative">
                                                <img
                                                    src={temp?.attributes?.images[0]?.srcUrl}
                                                    className="card-img-top"
                                                    alt="No-Image"
                                                    style={{ height: '250px', objectFit: 'cover' }}
                                                />
                                                <button className="HrtBtn position-absolute top-0 end-0 m-3">
                                                    <Heart size={18} style={{ color: '#fff' }} />
                                                </button>
                                            </div>
                                            <div className="card-body">
                                                <h5 className="card-title text-center">{temp?.attributes?.department}</h5>
                                                <p className="card-text text-muted small text-center">{temp?.attributes?.title}</p>
                                                <p className="card-text fw-bold text-center">{`${temp?.attributes?.price} ${temp?.attributes?.currency === 'GBP' ? '£' : ''}`}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))
                                :
                                loading ?
                                    <div className="d-flex justify-content-center align-items-center">
                                        <h6 className="text-center">Product Fetching ...</h6>
                                    </div>
                                    :
                                    tempLists.length === 0 ?
                                        <div className="d-flex justify-content-center align-items-center">
                                            <h6 className="text-center">No Results !</h6>
                                        </div>
                                        :
                                        null
                            }
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ProductLists;