import React from 'react'
import { Outlet } from 'react-router'

function AuthLayout(props) {
    return <Outlet {...props} />
}

export default AuthLayout