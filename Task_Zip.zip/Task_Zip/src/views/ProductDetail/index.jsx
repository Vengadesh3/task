import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Heart, HomeIcon, Share2 } from 'lucide-react';
import Loader from '../../Components/Loader';

const ProductDetails = () => {

    const { id } = useParams();
    const [details, setDetails] = useState("");
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        window.scroll({ top: 0 })
        fetchDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]);

    const fetchDetails = async () => {
        let response = await axios.get('https://mira-strapi-dev.q.starberry.com/api/properties/?_limit=50');
        if (response?.status === 200) {
            response = response?.data?.data
            response = response.find((temp) => temp?.id == id);
            setDetails(response?.attributes)
            setLoading(false)
        }
    }

    return (
        <section>
            <Loader loading={loading} />
            <div className="container my-4" >
                <div className="row">
                    {/* Left Section: Image Gallery */}
                    <div className="col-lg-7">
                        <div className="mb-3">
                            <img
                                src={details?.thumbnail}
                                alt="Main"
                                className="img-fluid"
                            />
                        </div>
                        <div className="row">
                            <div className="col-6">
                                <img
                                    src="https://via.placeholder.com/400x200"
                                    alt="Sub Image 1"
                                    className="img-fluid"
                                />
                            </div>
                            <div className="col-6">
                                <img
                                    src="https://via.placeholder.com/400x200"
                                    alt="Sub Image 2"
                                    className="img-fluid"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Right Section: Details */}
                    <div className="col-lg-5">
                        <div className="p-3">
                            <div className='d-flex justify-content-end gap-2'>
                                <Share2 size={20} type='button' />
                                <Heart size={20} type='button' />
                            </div>
                            <hr />
                            <div className='prdDtl'>
                                <h3>€ {details?.price} <span className='text-muted'>1 bed | 58 sqm</span></h3>
                                <h5>{details?.bedroom} bedroom |58 sqm</h5>
                                <p>{details?.slug}</p>
                                <a href='#' className='d-flex align-items-center cntLnk gap-2'>
                                    <HomeIcon size={16} />
                                    Please contact us
                                </a>
                                <button className="btn btn-dark btn-block w-100">Contact Agent</button>
                            </div>

                            <div className="mt-4 text-muted">
                                <h5 className='text-muted'>Facts & Features</h5>
                                <hr />
                                <table className="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <strong className="text-muted">Neighbourhood:</strong>
                                            </td>
                                            <td className='text-muted'>Fontvieille</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <strong className="text-muted">Price per sqm:</strong>
                                            </td>
                                            <td className='text-muted'>€{details?.price}</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <strong className="text-muted">Brochure:</strong>
                                            </td>
                                            <td className='text-muted'>Download Brochure</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <strong className="text-muted">Floor plan:</strong>
                                            </td>
                                            <td className='text-muted'>View Floorplan</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            {/* Description */}
                            <div className="mt-4">
                                <p>{details?.long_description}</p>
                            </div>

                            {/* Agent Info */}
                            <div className="d-flex align-items-center mt-4">
                                <img
                                    src="https://via.placeholder.com/50"
                                    alt="Agent"
                                    className="rounded-circle me-3"
                                />
                                <div>
                                    <h6 className="mb-0">Reka Demeter</h6>
                                    <p className="mb-0 text-muted">Real Estate Broker</p>
                                    <small className='text-muted'>+377 93 25 86 66 |{" "}</small>
                                    <small className='text-muted'>Email</small>
                                </div>
                            </div>

                            {/* Map */}
                            <div className="mt-4">
                                <iframe
                                    title="map"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151!2d144.9559253153157!3d-37.81720997975192!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf5772cd97ef7ab0b!2sVictoria!5e0!3m2!1sen!2sau!4v1634277332805!5m2!1sen!2sau"
                                    width="100%"
                                    height="150"
                                    style={{ border: 0 }}
                                    allowFullScreen=""
                                    loading="lazy"
                                ></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        </section>
    );
};

export default ProductDetails;