const Loader = ({ loading }) => {

    return (
        <div className={loading ? 'loading' : 'd-none'}>
            <img src='https://mir-s3-cdn-cf.behance.net/project_modules/disp/35771931234507.564a1d2403b3a.gif'
                alt="no-loader"
                className='img-fluid' width={80} />
        </div>
    )
}

export default Loader;