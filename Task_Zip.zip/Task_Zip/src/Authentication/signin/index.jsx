import React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'

function Singin() {
    const { handleSubmit, control, formState: { errors } } = useForm({ mode: "onTouched" })
    const navigate = useNavigate()

    const onsubmit = (data) => {
        navigate('/product-list')
    }

    return (
        <div className='LgnFrm'>
            <div className='card col-md-5'>
                <div className='card-body'>
                    <h2>Sign-in to your account.</h2>
                    <hr />
                    <form onSubmit={handleSubmit(onsubmit)}>
                        <div className='mb-3'>
                            <label className='form-label' htmlFor='email'>Email</label>
                            <Controller
                                control={control}
                                name='email'
                                rules={{
                                    required: "This field is required",
                                    pattern: {
                                        value: /^[a-zA-Z0-9_.±]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$/,
                                        message: "Invalid email"
                                    }
                                }}
                                render={({ field }) => (
                                    <input
                                        {...field}
                                        className='form-control'
                                        placeholder='example@gmail.com'
                                        type='email'
                                        id='email'
                                    />
                                )}
                            />
                            {errors.email && <span className='errMsg'>* {errors.email.message}</span>}
                        </div>
                        <div className='mb-3'>
                            <label className='form-label' htmlFor='password'>Password</label>
                            <Controller
                                control={control}
                                name='passwprd'
                                rules={{
                                    required: "This field is required",
                                    pattern: {
                                        value: /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.* ).{6,16}$/,
                                        message: "Password must contain least 6 characters (including number, lowercase, uppercase & special character)"
                                    }
                                }}
                                render={({ field }) => (
                                    <input
                                        {...field}
                                        className='form-control'
                                        placeholder='********'
                                        type='password'
                                        id='passwprd'
                                    />
                                )}
                            />
                            {errors.passwprd && <span className='errMsg'>* {errors.passwprd.message}</span>}
                        </div>
                        <div className='d-flex justify-content-center'>
                            <button className='btn btn-dark btn-block'>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Singin