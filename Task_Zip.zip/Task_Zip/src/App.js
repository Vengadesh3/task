import { Fragment, lazy } from 'react';
import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider } from 'react-router-dom';
import './App.css';

import AuthLayout from './Layouts/authLayout';
import RootLayout from './Layouts/rootLayout';

const ProductDetails = lazy(() => import("./views/ProductDetail"));
const ProductLists = lazy(() => import("./views/ProductList"));
const Singin = lazy(() => import('./Authentication/signin'));

function App() {

  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route>
        <Route path='/' element={<AuthLayout />}>
          <Route path='/' element={<Singin />} />
        </Route>

        <Route path='/' element={<RootLayout />}>
          <Route path='/product-list' element={<ProductLists />} />
          <Route path='/product-detail/:id' element={<ProductDetails />} />
        </Route>
      </Route>
    )
  )
  return (
    <Fragment>
      <RouterProvider router={router} />
    </Fragment>
  );
}

export default App;
